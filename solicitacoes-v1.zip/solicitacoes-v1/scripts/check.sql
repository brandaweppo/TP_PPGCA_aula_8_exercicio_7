\l
\c solicitacoes
\d pedidos